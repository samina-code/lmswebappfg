const form = document.getElementById("announcementForm");
const list = document.getElementById("announcementList");
let announcements = [];

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const semester = document.getElementById("semesterSelect").value;
  const subject = document.getElementById("subjectSelect").value;
  const type = document.getElementById("typeSelect").value;
  const title = document.getElementById("titleInput").value;
  const description = document.getElementById("descriptionInput").value;
  const date = document.getElementById("dateInput").value || new Date().toLocaleDateString();

  const announcement = {
    subject,
    semester,
    type,
    title,
    description,
    date
  };

  announcements.unshift(announcement);
  renderAnnouncements();
  form.reset();
});

function renderAnnouncements() {
  list.innerHTML = "";

  announcements.forEach(ann => {
    const card = document.createElement("div");
    card.className = "announcement-card";

    card.innerHTML = `
      <h4>${ann.title} <small>(${ann.type})</small></h4>
      <p><strong>Subject:</strong> ${ann.subject} | <strong>Semester:</strong> ${ann.semester}</p>
      <p>${ann.description}</p>
      <small>Posted on: ${ann.date}</small>
    `;

    list.appendChild(card);
  });
}
