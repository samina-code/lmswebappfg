document.addEventListener("DOMContentLoaded", function () {
  const quizData = {
    6: {
      "Artificial Intelligence": [
        { id: 1, title: "Intro to AI Quiz", dueDate: "2024-04-25", status: "Not Attempted" },
        { id: 2, title: "Search Algorithms Quiz", dueDate: "2024-05-01", status: "Submitted" }
      ],
      "Web Development": [
        { id: 3, title: "HTML Basics Quiz", dueDate: "2024-04-28", status: "In Progress" }
      ]
    }
  };

  const assignedSemester = 6;
  const quizContainer = document.getElementById("quizContainer");
  const subjects = quizData[assignedSemester] || {};
  quizContainer.innerHTML = "";

  Object.keys(subjects).forEach(subject => {
    const block = document.createElement("div");
    block.className = "subject-block";

    const heading = document.createElement("h3");
    heading.textContent = subject;
    block.appendChild(heading);

    const table = document.createElement("table");
    table.className = "quiz-table";

    table.innerHTML = `
      <thead>
        <tr>
          <th>Quiz Title</th>
          <th>Due Date</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody></tbody>
    `;

    const tbody = table.querySelector("tbody");

    subjects[subject].forEach(quiz => {
      const row = document.createElement("tr");
      const statusClass = quiz.status.replace(" ", "-").toLowerCase();

      row.innerHTML = `
        <td>${quiz.title}</td>
        <td>${quiz.dueDate}</td>
        <td><span class="status ${statusClass}">${quiz.status}</span></td>
        <td>${generateActionButton(quiz.status, quiz.id, quiz.title)}</td>
      `;

      tbody.appendChild(row);
    });

    block.appendChild(table);
    quizContainer.appendChild(block);
  });

  function generateActionButton(status, quizId, title) {
    if (status === "Not Attempted") {
      return `<button class="quiz-btn" onclick="startQuiz(${quizId})">Start Quiz</button>`;
    } else if (status === "In Progress") {
      return `<button class="quiz-btn" onclick="startQuiz(${quizId})">Continue</button>`;
    } else if (status === "Submitted") {
      return `<button class="quiz-btn" onclick="openResultModal(${quizId}, '${title}')">View Result</button>`;
    }
    return '';
  }
});

function startQuiz(quizId) {
  window.location.href = `startquiz.html?quizId=${quizId}`;
}

function openResultModal(quizId, title) {
  const modal = document.createElement("div");
  modal.className = "modal";
  modal.innerHTML = `
    <div class="modal-content">
      <span class="close-btn" onclick="this.closest('.modal').remove()">&times;</span>
      <h2>Quiz Result: <span id="quizTitle">${title}</span></h2>
      <p><strong>Score:</strong> <span id="quizScore">8 / 10</span></p>
      <ul id="questionResults">
        <li>✔️ Q1 - Correct</li>
        <li>❌ Q2 - Incorrect</li>
        <li>✔️ Q3 - Correct</li>
      </ul>
      <button onclick="downloadResultPDF('${title}')" class="download-btn">Download as PDF</button>
    </div>
  `;
  document.body.appendChild(modal);
}

async function downloadResultPDF(title) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  const score = document.getElementById("quizScore").textContent;
  const questions = document.querySelectorAll("#questionResults li");

  doc.setFontSize(16);
  doc.text("Quiz Result: " + title, 20, 20);
  doc.setFontSize(12);
  doc.text("Score: " + score, 20, 30);

  questions.forEach((item, index) => {
    doc.text(item.textContent, 20, 40 + index * 10);
  });

  doc.save("Quiz_Result.pdf");
}
