// Toggle Functions
function toggleNotifications() {
  const popup = document.getElementById('notificationsPopup');
  popup.style.display = popup.style.display === 'block' ? 'none' : 'block';
}

function toggleProfileMenu() {
  const menu = document.getElementById('profileMenu');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

function markAsRead(elem) {
  elem.style.textDecoration = "line-through";
}

function toggleDarkMode() {
  document.body.classList.toggle("dark");
}

// ✅ Chart.js Graphs
window.onload = function () {
  // Bar Chart
  const barChart = new Chart(document.getElementById("barChart"), {
    type: 'bar',
    data: {
      labels: ["Quiz 1", "Quiz 2", "Quiz 3", "Quiz 4"],
      datasets: [{
        label: "Scores",
        data: [75, 82, 90, 68],
        backgroundColor: "#0077cc"
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });

  // Doughnut Chart
  const doughnutChart = new Chart(document.getElementById("doughnutChart"), {
    type: 'doughnut',
    data: {
      labels: ["Completed", "Pending"],
      datasets: [{
        data: [70, 30],
        backgroundColor: ["#28a745", "#ffc107"]
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom'
        }
      }
    }
  });
};
