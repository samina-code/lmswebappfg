const form = document.getElementById('uploadForm');
const list = document.getElementById('materialList');

let uploadedMaterials = [];

form.addEventListener('submit', function (e) {
  e.preventDefault();

  const subject = document.getElementById('subjectSelect').value;
  const semester = document.getElementById('semesterSelect').value;
  const title = document.getElementById('lectureTitle').value;
  const fileInput = document.getElementById('pdfFile');
  const file = fileInput.files[0];

  if (file && file.type === "application/pdf") {
    const material = {
      subject,
      semester,
      title,
      fileName: file.name,
      date: new Date().toLocaleDateString()
    };

    uploadedMaterials.push(material);
    displayMaterials();
    form.reset();
  } else {
    alert("Please upload a valid PDF file.");
  }
});

function displayMaterials() {
  list.innerHTML = "";

  uploadedMaterials.forEach((material, index) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <span>
        📘 <strong>${material.title}</strong> 
        (${material.subject} - ${material.semester}) 
        [${material.fileName}] - ${material.date}
      </span>
      <button onclick="viewMaterial('${material.fileName}')">View</button>
      <button onclick="downloadMaterial('${material.fileName}')">Download</button>
      <button class="delete-btn" onclick="deleteMaterial(${index})">Delete</button>
    `;
    list.appendChild(li);
  });
}

function viewMaterial(fileName) {
  alert("👁 View: " + fileName + "\n(Simulation)");
}

function downloadMaterial(fileName) {
  alert("📥 Download: " + fileName + "\n(Simulation)");
}

function deleteMaterial(index) {
  if (confirm("Are you sure to delete this file?")) {
    uploadedMaterials.splice(index, 1);
    displayMaterials();
  }
}
