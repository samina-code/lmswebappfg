document.getElementById("quizForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    // You can collect and send data here
    document.getElementById("resultMessage").textContent = "🎉 Quiz submitted successfully!";
  });
  