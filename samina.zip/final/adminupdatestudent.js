
  function confirmUpdate() {
    return confirm("Are you sure? This record and its details will be permanently deleted.");
  }
