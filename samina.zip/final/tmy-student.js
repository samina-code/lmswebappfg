const students = [
    { name: 'Areeba Khan', semester: '2', photo: 'https://randomuser.me/api/portraits/women/65.jpg', grade: 'A' },
    { name: 'Hamza Ali', semester: '2', photo: 'https://randomuser.me/api/portraits/men/23.jpg', grade: 'B+' },
    { name: 'Fatima Raza', semester: '4', photo: 'https://randomuser.me/api/portraits/women/76.jpg', grade: 'A-' },
    { name: 'Bilal Ahmed', semester: '4', photo: 'https://randomuser.me/api/portraits/men/33.jpg', grade: 'B' },
    { name: 'Sarah Malik', semester: '6', photo: 'https://randomuser.me/api/portraits/women/44.jpg', grade: 'A+' },
    { name: 'Daniyal Qureshi', semester: '6', photo: 'https://randomuser.me/api/portraits/men/19.jpg', grade: 'B+' },
    { name: 'Mariam Yousaf', semester: '8', photo: 'https://randomuser.me/api/portraits/women/55.jpg', grade: 'A' },
    { name: 'Zain Shah', semester: '8', photo: 'https://randomuser.me/api/portraits/men/45.jpg', grade: 'A-' },
  ];
  
  const semesterFilter = document.getElementById('semesterFilter');
  const searchInput = document.getElementById('searchInput');
  const container = document.getElementById('studentsContainer');
  
  function renderStudents() {
    const semester = semesterFilter.value;
    const search = searchInput.value.toLowerCase();
  
    const filtered = students.filter(s => {
      const matchesSemester = semester === 'All' || s.semester === semester;
      const matchesSearch = s.name.toLowerCase().includes(search);
      return matchesSemester && matchesSearch;
    });
  
    container.innerHTML = '';
  
    if (filtered.length === 0) {
      container.innerHTML = '<p>No students found.</p>';
      return;
    }
  
    filtered.forEach(student => {
      const card = document.createElement('div');
      card.className = 'student-card';
      card.innerHTML = `
        <img src="${student.photo}" alt="${student.name}">
        <h4>${student.name}</h4>
        <p>Semester: ${student.semester}</p>
        <p>Grade: ${student.grade}</p>
        <div class="student-actions">
          <a href="mailto:${student.name.split(' ').join('').toLowerCase()}@example.com"><i class="fas fa-envelope"></i> Email</a>
          <a href="profile.html"><i class="fas fa-user-circle"></i> View Profile</a>
        </div>
      `;
      container.appendChild(card);
    });
  }
  
  semesterFilter.addEventListener('change', renderStudents);
  searchInput.addEventListener('input', renderStudents);
  
  window.addEventListener('DOMContentLoaded', renderStudents);
  