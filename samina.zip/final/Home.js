// Add any interactivity here
console.log('Page loaded successfully');
