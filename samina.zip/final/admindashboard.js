// 🌑 Dark Mode Toggle
document.getElementById("darkModeToggle").addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");
  });
  
  // 📊 Chart 1 – Students by Semester
  new Chart(document.getElementById("studentChart"), {
    type: "bar",
    data: {
      labels: [ "2", "4", "6",  "8"],
      datasets: [{
        label: "Students",
        data: [40, 45, 38, 33, 41, ],
        backgroundColor: "#0066cc"
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
  
  // 📊 Chart 2 – Teachers by Dept
  new Chart(document.getElementById("teacherChart"), {
    type: "pie",
    data: {
      labels: ["2", "4", "6", "8"],
      datasets: [{
        data: [12, 8, 6, 4],
        backgroundColor: ["#003366", "#0055aa", "#0077cc", "#3399ff"]
      }]
    },
    options: {
      plugins: { legend: { position: "bottom" } }
    }
  });
  
  // 📊 Chart 3 – Semester Activity
  new Chart(document.getElementById("semesterChart"), {
    type: "line",
    data: {
      labels: ["Jan", "Mar", "May", "Jul", "Sep", "Nov"],
      datasets: [{
        label: "New Semesters",
        data: [1, 0, 2, 1, 2, 0],
        borderColor: "#003366",
        tension: 0.4,
        fill: false
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } }
    }
  });
  