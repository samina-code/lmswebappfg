const form = document.getElementById("performanceForm");
const list = document.getElementById("performanceList");

let records = [];

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const data = {
    name: document.getElementById("studentName").value,
    roll: document.getElementById("rollNo").value,
    semester: document.getElementById("semesterSelect").value,
    subject: document.getElementById("subjectSelect").value,
    assignment: parseFloat(document.getElementById("assignment").value),
    quiz: parseFloat(document.getElementById("quiz").value),
    mid: parseFloat(document.getElementById("mid").value),
    final: parseFloat(document.getElementById("final").value),
  };

  const total = data.assignment + data.quiz + data.mid + data.final;
  data.cgpa = (total / 210 * 4).toFixed(2);

  records.push(data);
  renderList();
  form.reset();
});

function renderList() {
  list.innerHTML = "";

  records.forEach((rec, index) => {
    const card = document.createElement("div");
    card.className = "record-card";
    card.innerHTML = `
      <p><strong>Name:</strong> ${rec.name}</p>
      <p><strong>Roll No:</strong> ${rec.roll}</p>
      <p><strong>Semester:</strong> ${rec.semester} | <strong>Subject:</strong> ${rec.subject}</p>
      <p>📝 Assignment: ${rec.assignment}/40 | 🧪 Quiz: ${rec.quiz}/20</p>
      <p>🧾 Midterm: ${rec.mid}/50 | 🎓 Final: ${rec.final}/100</p>
      <p class="cgpa">📊 CGPA: ${rec.cgpa}</p>
      <button class="delete-btn" onclick="deleteRecord(${index})">❌ Delete</button>
    `;
    list.appendChild(card);
  });
}

function deleteRecord(index) {
  if (confirm("Are you sure you want to delete this record?")) {
    records.splice(index, 1);
    renderList();
  }
}
