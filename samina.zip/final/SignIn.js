JavaScript (script.js)

document.querySelector("form").addEventListener("submit", function (e) {
    e.preventDefault();
    const email = document.querySelector('input[type="email"]').value;
    const password = document.querySelector('input[type="password"]').value;

    if (email && password) {
        alert("Login successful!");
    } else {
        alert("Please fill in all fields.");
    }
});
function validateForm() {
    // Get the form elements
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Regular expression for email validation
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    // Email validation
    if (!email.match(emailPattern)) {
        alert("Please enter a valid email address.");
        return false; // Prevent form submission
    }

    // Password validation (check if it's empty)
    if (password.trim() === "") {
        alert("Password cannot be empty.");
        return false; // Prevent form submission
    }

    // Password strength validation
    var passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;

    if (!password.match(passwordPattern)) {
        alert("Password must be between 8 and 16 characters long and include at least one letter, one number, and one special character.");
        return false; // Prevent form submission
    }

    return true; // Allow form submission if validation passes
}
function validateForm() {
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value.trim();

    // Admin check
    if (email === "samina@gmail.com" && password === "samina") {
        window.location.href = "admindashboard.html";
        return false;
    }

    // Teacher check
    const teacherAccounts = [
        { email: "madeeha@gmail.com", password: "madeeha" },
        { email: "kiran@gmail.com", password: "kiran" },
        { email: "fatima@gmail.com", password: "fatima" }
    ];

    const isTeacher = teacherAccounts.some(acc => acc.email === email && acc.password === password);
    if (isTeacher) {
        window.location.href = "teacherdashboard.html";
        return false;
    }

    // Student fallback
    window.location.href = "id.html";
    return false; // prevent actual form submission
}


