document.addEventListener("DOMContentLoaded", function () {
  const subjectData = {
    6: [
      {
        name: "Artificial Intelligence",
        teacher: "Dr. Sarah Khan",
        image: "https://randomuser.me/api/portraits/women/44.jpg",
        materials: [
          { title: "Intro to AI", file: "ai_intro.pdf" },
          { title: "Search Strategies", file: "ai_search.pdf" }
        ]
      },
      {
        name: "Web Development",
        teacher: "Mr. Ahmed Raza",
        image: "https://randomuser.me/api/portraits/men/65.jpg",
        materials: [
          { title: "HTML Basics", file: "web_html.pdf" },
          { title: "CSS Styling", file: "web_css.pdf" }
        ]
      }
    ]
  };

  const assignedSemester = 6;
  const container = document.getElementById("subjectContainer");
  const searchInput = document.getElementById("searchInput");
  const subjects = subjectData[assignedSemester];

  function displaySubjects(subjectList) {
    container.innerHTML = "";

    subjectList.forEach(subject => {
      const card = document.createElement("div");
      card.className = "subject-card";

      const title = document.createElement("h3");
      title.textContent = subject.name;
      card.appendChild(title);

      const teacherCard = document.createElement("div");
      teacherCard.className = "teacher-card";
      teacherCard.innerHTML = `
        <img src="${subject.image}" class="teacher-pic" alt="Teacher">
        <div class="teacher-details">
          <strong>${subject.teacher}</strong><br>
          <span>Subject: ${subject.name}</span>
        </div>
      `;
      card.appendChild(teacherCard);

      const list = document.createElement("div");
      list.className = "lecture-list";

      subject.materials.forEach(mat => {
        const item = document.createElement("p");
        item.innerHTML = `
          <i class="fas fa-file-pdf"></i>
          <a href="${mat.file}" target="_blank">${mat.title}</a>
          <button class="feedback-btn" onclick="openFeedbackModal('${mat.title}')">Give Feedback</button>
        `;
        list.appendChild(item);
      });

      card.appendChild(list);
      container.appendChild(card);
    });
  }

  displaySubjects(subjects);

  searchInput.addEventListener("input", function () {
    const keyword = this.value.toLowerCase();
    const filtered = subjects.filter(sub =>
      sub.name.toLowerCase().includes(keyword) ||
      sub.teacher.toLowerCase().includes(keyword)
    );
    displaySubjects(filtered);
  });
});

let selectedLecture = "";

function openFeedbackModal(lectureName) {
  selectedLecture = lectureName;
  document.getElementById("lectureTitle").textContent = "Lecture: " + lectureName;
  document.getElementById("feedbackText").value = "";
  document.getElementById("rating").value = "5";
  document.getElementById("feedbackMsg").textContent = "";
  document.getElementById("feedbackModal").style.display = "block";
}

document.querySelector(".close").onclick = function () {
  document.getElementById("feedbackModal").style.display = "none";
};

document.getElementById("submitFeedbackBtn").onclick = function () {
  const feedback = document.getElementById("feedbackText").value;
  const rating = document.getElementById("rating").value;

  if (!feedback.trim()) {
    document.getElementById("feedbackMsg").textContent = "Feedback cannot be empty.";
    return;
  }

  Swal.fire({
    title: "Feedback Sent!",
    text: "Thank you for your response.",
    icon: "success",
    confirmButtonText: "OK"
  });

  setTimeout(() => {
    document.getElementById("feedbackModal").style.display = "none";
  }, 1500);
};

window.onclick = function(event) {
  if (event.target === document.getElementById("feedbackModal")) {
    document.getElementById("feedbackModal").style.display = "none";
  }
};