function assignSubject() {
    alert("Are you sure? This will assign the subject permanently.");
  
    // After confirmation, show toast (you can replace this with a real toast UI)
    setTimeout(() => {
      alert("Subject assigned successfully.");
    }, 300);
  }
  