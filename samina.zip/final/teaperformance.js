const students = [
    {
      name: "Areeba Khan",
      roll: "FA20-BCS-001",
      semester: "6th",
      subject: "Web Development",
      photo: "https://randomuser.me/api/portraits/women/1.jpg",
      assignment: 38,
      quiz: 18,
      mid: 40,
      final: 75
    },
    {
      name: "Hassan Ali",
      roll: "FA20-BCS-002",
      semester: "6th",
      subject: "Artificial Intelligence",
      photo: "https://randomuser.me/api/portraits/men/2.jpg",
      assignment: 35,
      quiz: 16,
      mid: 37,
      final: 80
    }
  ];
  
  const container = document.getElementById("performanceList");
  const searchInput = document.getElementById("searchInput");
  
  function renderStudents() {
    const term = searchInput.value.toLowerCase();
    container.innerHTML = "";
  
    students.forEach(student => {
      if (
        student.name.toLowerCase().includes(term) ||
        student.roll.toLowerCase().includes(term)
      ) {
        const cgpa = calculateCGPA(student);
        const card = document.createElement("div");
        card.className = "student-card";
  
        card.innerHTML = `
          <img src="${student.photo}" class="profile-pic" alt="Student Photo" />
          <div class="student-info">
            <h4>${student.name}</h4>
            <p><strong>Roll No:</strong> ${student.roll}</p>
            <p><strong>Subject:</strong> ${student.subject} | <strong>Semester:</strong> ${student.semester}</p>
  
            <div class="score-grid">
              <p><strong><i class="fas fa-file-upload"></i>  Assignment:</strong> ${student.assignment}/40</p>
              <p><strong><i class="fas fa-question-circle"></i> Quiz:</strong> ${student.quiz}/20</p>
              <p><strong><i class="fas fa-pencil-alt"></i> Midterm:</strong> ${student.mid}/50</p>
              <p><strong><i class="fas fa-file-alt"></i>  Final:</strong> ${student.final}/100</p>
            </div>
  
            <p class="cgpa">📊 CGPA: ${cgpa}</p>
          </div>
        `;
  
        container.appendChild(card);
      }
    });
  }
  
  function calculateCGPA(student) {
    const total = student.assignment + student.quiz + student.mid + student.final;
    const percentage = (total / 210) * 100;
    return (percentage / 25).toFixed(2); // CGPA scale out of 4.0
  }
  
  searchInput.addEventListener("input", renderStudents);
  renderStudents();
  