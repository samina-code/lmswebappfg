const container = document.getElementById("questionsContainer");
const form = document.getElementById("quizForm");
let questionCount = 0;

// ➕ Add Question Block
function addQuestion() {
  questionCount++;
  const block = document.createElement("div");
  block.className = "question-block";
  block.innerHTML = `
    <h4>Question ${questionCount}</h4>
    <label>Question:</label>
    <textarea required></textarea>

    <label>Option A:</label>
    <input type="text" required>

    <label>Option B:</label>
    <input type="text" required>

    <label>Option C:</label>
    <input type="text" required>

    <label>Option D:</label>
    <input type="text" required>

    <label>Correct Answer:</label>
    <select required>
      <option value="">--Select--</option>
      <option value="A">Option A</option>
      <option value="B">Option B</option>
      <option value="C">Option C</option>
      <option value="D">Option D</option>
    </select>

    <button type="button" class="remove-btn" onclick="this.parentElement.remove()">❌ Remove</button>
  `;
  container.appendChild(block);
}

// 🧾 Submit Quiz (simulation)
form.addEventListener("submit", function (e) {
  e.preventDefault();
  alert("✅ Quiz created successfully!\n(This is a simulation for frontend only)");
  form.reset();
  container.innerHTML = "";
  questionCount = 0;
});
