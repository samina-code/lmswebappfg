// 🔷 Sample subject data with teacher, lectures & feedback
const subjects = [
  {
    semester: "6th",
    name: "Artificial Intelligence",
    schedule: "Mon/Wed 10AM",
    days: "2 days/week",
    assignedOn: "2024-03-10",
    teacher: {
      name: "Ms. Ayesha Khan",
      photo: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
    },
    
  },
  {
    semester: "4th",
    name: "Data Structures",
    schedule: "Tue/Thu 11AM",
    days: "2 days/week",
    assignedOn: "2024-02-01",
    teacher: {
      name: "Sir Ahmed Raza",
      photo: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
    },
  
  },
  {
    semester: "4th",
    name: "Operating Systems",
    schedule: "Mon/Wed 2PM",
    days: "2 days/week",
    assignedOn: "2024-03-28",
    teacher: {
      name: "Ms. Fatima Noor",
      photo: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
    },
   
  },
  {
    semester: "6th",
    name: "Web Development",
    schedule: "Fri 9AM",
    days: "1 day/week",
    assignedOn: "2024-04-02",
    teacher: {
      name: "Sir Bilal Sheikh",
      photo: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
    },
    lectures: []
  }
];

const container = document.getElementById("subjectContainer");
const searchInput = document.getElementById("searchInput");
const semesterFilter = document.getElementById("semesterFilter");

function renderSubjects() {
  container.innerHTML = "";
  const searchTerm = searchInput.value.toLowerCase();
  const selectedSemester = semesterFilter.value;

  subjects.forEach(sub => {
    if (
      (selectedSemester === "all" || sub.semester === selectedSemester) &&
      sub.name.toLowerCase().includes(searchTerm)
    ) {
      const card = document.createElement("div");
      card.className = "subject-card";
      card.innerHTML = `
        <h3>${sub.name}</h3>
        <div class="teacher-info">
          <img src="${sub.teacher.photo}" alt="Teacher Photo" class="teacher-photo" />
          <span><strong>${sub.teacher.name}</strong></span>
        </div>
        <p><strong>Semester:</strong> ${sub.semester}</p>
        <p><strong>Class Days:</strong> ${sub.days}</p>
        <p><strong>Schedule:</strong> ${sub.schedule}</p>
        <p><strong>Assigned On:</strong> ${sub.assignedOn}</p>
      `;
      container.appendChild(card);
    }
  });
}

searchInput.addEventListener("input", renderSubjects);
semesterFilter.addEventListener("change", renderSubjects);

renderSubjects();
