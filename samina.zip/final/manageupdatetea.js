function updateTeacher() {
    const confirmation = confirm("Are you sure? Previous data will be permanently deleted!");
  
    if (confirmation) {
      const name = document.getElementById("teacherName").value;
      const email = document.getElementById("teacherEmail").value;
      const contact = document.getElementById("teacherContact").value;
      const qualification = document.getElementById("teacherQualification").value;
  
      showToast("Teacher data updated successfully!");
    } else {
      alert("Update cancelled.");
    }
  }
  
  function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.innerText = message;
    document.body.appendChild(toast);
  
    setTimeout(() => {
      toast.classList.add("show");
    }, 100);
  
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }
  $(document).ready(function() {
    $('#teachersTable').DataTable();
  
    // DELETE button functionality
    $('#teachersTable').on('click', '.delete-btn', function() {
      const row = $(this).closest('tr');
      const teacherName = row.find('td:eq(2)').text(); // Get teacher name
  
      if (confirm(`Are you sure you want to delete ${teacherName}?`)) {
        row.remove();
        alert(`${teacherName} has been deleted.`);
      }
    });
  });
  