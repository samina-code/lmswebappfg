from django.shortcuts import render

def home(request):
    return render(request, 'backend/Home.html')

def login_view(request):
    return render(request, 'backend/SignIn.html')

def signup_view(request):
    return render(request, 'backend/SignUp.html')

def contact_view(request):
    return render(request, 'backend/Contact.html')
